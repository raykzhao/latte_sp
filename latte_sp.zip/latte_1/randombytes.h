#ifndef rng_h
#define rng_h

int
randombytes(unsigned char *x, unsigned long long xlen);

#endif /* rng_h */
