#ifndef _SAMPLE_Z_H
#define _SAMPLE_Z_H

#include "poly.h"

int64_t sample_z(const double center, const double sigma);
void sample_e(POLY_64 *out);
void sample_0z(POLY_64 *sample);

#endif
