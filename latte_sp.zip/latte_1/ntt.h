#ifndef _NTT_H
#define _NTT_H

#include "poly.h"

void ntt(POLY_64 *a);
void intt(POLY_64 *a);


#endif
